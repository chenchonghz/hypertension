# d3-book
=======

These are sample code files to accompany the book “Interactive Data Visualization for the Web” by Scott Murray, published in March 2013 by O’Reilly.

- [O’Reilly book page](http://shop.oreilly.com/product/0636920026938.do)
- [Free chapter previews](http://ofps.oreilly.com/titles/9781449339739/)

### License

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.

http://creativecommons.org/licenses/by-nc-nd/3.0/
